//
//  ViewController.swift
//  Introduce Your Family
//
//  Created by Kai Liberal on 2/19/25.
//

import UIKit

class DetailViewController: UIViewController {
    
    var selectedFamilyMember: FamilyMember?
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var hobbyLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let selectedFamilyMember {
            nameLabel.text = selectedFamilyMember.name
            ageLabel.text = selectedFamilyMember.age
            hobbyLabel.text = selectedFamilyMember.hobbies
        }
    }
    
    
}

