//
//  ViewController.swift
//  Introduce Your Family
//
//  Created by Kai Liberal on 2/19/25.
//

import UIKit

class FamilyMember {
    var name: String = ""
    var age: String = ""
    var hobbies: String = ""
    
    init(name: String, age: String, hobbies: String) {
        self.name = name
        self.age = age
        self.hobbies = hobbies
    }
}

class MainViewController: UITableViewController {
    var familyMembers: [FamilyMember] = []
    var selectedFamilyMember: FamilyMember?
    
    func loadData() {
        var dad = FamilyMember(name: "Rod", age: "49", hobbies: "Music, skydive, languages")
        familyMembers.append(dad)
        
        var mom = FamilyMember(name: "Jody", age: "46", hobbies: "Reading, cooking, hiking")
        familyMembers.append(mom)
        
        var brennan = FamilyMember(name: "Brennan", age: "19", hobbies: "Games, guitar, snowboarding")
        familyMembers.append(brennan)

        var easton = FamilyMember(name: "Easton", age: "14", hobbies: "Games, soccer, jiu jitsu")
        familyMembers.append(easton)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadData()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        familyMembers.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "familyMemberCell", for: indexPath)
        cell.textLabel?.text = familyMembers[indexPath.row].age
        cell.detailTextLabel?.text = familyMembers[indexPath.row].name
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedFamilyMember = familyMembers[indexPath.row]
        
        performSegue(withIdentifier: "detailSegue", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let destinationViewController = segue.destination as? DetailViewController else {
            fatalError("Unexpected destination: \(segue.destination)")
        }
        
        destinationViewController.selectedFamilyMember = selectedFamilyMember
       
    }

//    @IBAction func dadButtonPressed(_ sender: Any) {
//        selectedFamilyMember = dad
//        performSegue(withIdentifier: "detailSegue", sender: sender)
//    }
//    @IBAction func momButtonPressed(_ sender: Any) {
//        selectedFamilyMember = mom
//        performSegue(withIdentifier: "detailSegue", sender: sender)
//
//    }
//    @IBAction func brennanButtonPressed(_ sender: Any) {
//        selectedFamilyMember = brennan
//        performSegue(withIdentifier: "detailSegue", sender: sender)
//
//    }
//    @IBAction func eastonButtonPressed(_ sender: Any) {
//        selectedFamilyMember = easton
//        performSegue(withIdentifier: "detailSegue", sender: sender)
//
//    }
    

}

