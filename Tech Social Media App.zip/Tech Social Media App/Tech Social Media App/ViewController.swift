//
//  ViewController.swift
//  Tech Social Media App
//
//  Created by Kai Liberal on 3/12/25.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var profilePictureImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        profilePictureImage.layer.cornerRadius = profilePictureImage.frame.width / 2
        profilePictureImage.clipsToBounds = true
        // Do any additional setup after loading the view.
    }
    
}
