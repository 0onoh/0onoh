//
//  Tech_Social_Media_AppTests.swift
//  Tech Social Media AppTests
//
//  Created by Kai Liberal on 3/12/25.
//

import Testing
@testable import Tech_Social_Media_App

struct Tech_Social_Media_AppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
