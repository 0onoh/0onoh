//
//  ViewController.swift
//  Calculator
//
//  Created by Kai Liberal on 2/10/25.
//

import UIKit


class ViewController: UIViewController {
    
    @IBOutlet weak var operationLabel: UILabel!
    @IBOutlet weak var resultsLabel: UILabel!
    
    var operation: String = ""
    var shouldResetOperation: Bool = false
    
    func clearAll() {
        operation = ""
        operationLabel.text = ""
        resultsLabel.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        clearAll()
        // Do any additional setup after loading the view.
    }
    
    func addToOperations(value: String) {
        if shouldResetOperation {
            if let _ = Double(value) { // If the value is a number, start fresh
                operation = value
                resultsLabel.text = "" // Clear the result label
            } else { // If the value is an operator, continue the operation
                operation += value
            }
            shouldResetOperation = false
        } else {
            operation += value
        }
        operationLabel.text = operation
    }
    
    @IBAction func clearButtonPressed(_ sender: Any) {
        clearAll()
    }
    
    @IBAction func positiveNegativeButtonPressed(_ sender: Any) {
    }
    
    @IBAction func percentButtonPressed(_ sender: Any) {
        addToOperations(value: "%")
    }
    
    @IBAction func divideButtonPressed(_ sender: Any) {
        addToOperations(value: "/")
        
    }
    
    @IBAction func multiplyButtonPressed(_ sender: Any) {
        addToOperations(value: "*")
        
    }
    
    @IBAction func subtractButtonPressed(_ sender: Any) {
        addToOperations(value: "-")
        
    }
    
    @IBAction func addButtonPressed(_ sender: Any) {
        addToOperations(value: "+")
        
    }
    
    func formatResult(result: Double) -> String {
        if result.truncatingRemainder(dividingBy: 1) == 0 {
            print("\(result)")
            return String(format: "%.0f", result) // Whole number, no decimals
        } else {
            print("\(result)")
            return String(result) // Automatically show all available decimals
        }
    }
    
    func validInput() -> Bool {
        
        var count = 0
        var charIndex = [Int] ()
        
        for char in operation {
            if (checkSpecialCharater(char: char)) {
                charIndex.append(count)
            }
            count += 1
        }
        
        var previous: Int = -1
        
        for index in charIndex {
            if index == 0 || index == operation.count - 1 {
                return false
            }
            if previous != -1 {
                if (index - previous == 1) {
                    return false
                }
            }
            previous = index
        }
        return true
    }
    
 
    
    func checkSpecialCharater(char: Character) -> Bool {
        
        if (char == "*") {
            return true
        }
        if (char == "/") {
            return true
        }
        if (char == "+") {
            return true
        }
        return false
    }
    
    
    @IBAction func equalsButtonPressed(_ sender: Any) {
        if validInput() {
            var checkedOperation = operation.replacingOccurrences(of: "%", with: "*0.01")
            
            // Ensure all numbers are treated as floating-point values
            checkedOperation = checkedOperation.replacingOccurrences(of: "([0-9]+)", with: "$1.0", options: .regularExpression)
            
            let expression = NSExpression(format: checkedOperation)
            if let result = expression.expressionValue(with: nil, context: nil) as? Double {
                let resultString = formatResult(result: result)
                resultsLabel.text = resultString
                operation = resultString // Store result for further operations
                shouldResetOperation = true // Mark reset flag
            } else {
                resultsLabel.text = "Err"
            }
        } else {
            resultsLabel.text = "Err"
        }
    }
    
    @IBAction func decimalButtonPressed(_ sender: Any) {
        addToOperations(value: ".")
    }
    
    @IBAction func zeroButtonPressed(_ sender: Any) {
        addToOperations(value: "0")
    }
    
    @IBAction func oneButtonPressed(_ sender: Any) {
        addToOperations(value: "1")
    }
    
    @IBAction func twoButtonPressed(_ sender: Any) {
        addToOperations(value: "2")
    }
    
    @IBAction func threeButtonPressed(_ sender: Any) {
        addToOperations(value: "3")
    }
    
    @IBAction func fourButtonPressed(_ sender: Any) {
        addToOperations(value: "4")
    }
    
    @IBAction func fiveButtonPressed(_ sender: Any) {
        addToOperations(value: "5")
    }
    
    @IBAction func sixButtonPressed(_ sender: Any) {
        addToOperations(value: "6")
    }
    
    @IBAction func sevenButtonPressed(_ sender: Any) {
        addToOperations(value: "7")
    }
    
    @IBAction func eightButtonPressed(_ sender: Any) {
        addToOperations(value: "8")
    }
    
    @IBAction func nineButtonPressed(_ sender: Any) {
        addToOperations(value: "9")
    }
  
}
